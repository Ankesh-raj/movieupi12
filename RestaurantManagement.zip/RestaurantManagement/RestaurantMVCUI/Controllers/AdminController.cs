﻿using Microsoft.AspNetCore.Mvc;

namespace RestaurantMVCUI.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
