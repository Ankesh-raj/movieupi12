﻿using Microsoft.AspNetCore.Mvc;

namespace RestaurantMVCUI.Controllers
{
    public class BillController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
